# Print when mounted


Print to console using console.log when component is mounted.

print "mounted" when component is mounted.

Also do not remove the console.log statement in render.